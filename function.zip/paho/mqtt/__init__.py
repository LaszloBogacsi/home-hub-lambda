__version__ = "1.4.0"


class MQTTException(Exception):
    pass
